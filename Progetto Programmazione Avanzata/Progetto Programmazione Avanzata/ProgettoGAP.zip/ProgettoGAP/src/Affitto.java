/*Affitto.java*/

import java.time.*;
import java.time.format.DateTimeFormatter;
import static java.time.temporal.ChronoUnit.DAYS;
import javafx.beans.property.*;

public class Affitto {
    private final SimpleLongProperty idAffitto;
    private final SimpleStringProperty locale;
    private final SimpleStringProperty stato;
    private final SimpleStringProperty checkin;
    private final SimpleStringProperty checkout;
    private final SimpleStringProperty affittoGiornaliero;
    private final SimpleStringProperty incassoTotale;
    private final SimpleStringProperty tasse;
    private final SimpleStringProperty guadagnoNetto;
    private double valoreIncassoTotale;
    private final double valoreTasse;
    private final double valoreGuadagnoNetto;
    private final LocalDate dataCheckout;
    private final LocalDate dataCheckin;
    private final long numeroNotti;
    private final long numeroNottiMeseCheckin;
    private final long numeroNottiMeseCheckout;
    private final String formattazione;
                                                               
    Affitto(long idAffitto, String locale, LocalDate checkin, LocalDate checkout, double affittoGiornaliero, double percentualeTasse, String formattazione){
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd LLLL yyyy"); //formatta la data nel formato indicato

        this.idAffitto = new SimpleLongProperty(idAffitto);
        this.locale = new SimpleStringProperty(locale);
        dataCheckout = checkout;
        this.checkin = new SimpleStringProperty(checkin.format(formatter));
        dataCheckin = checkin;
        this.checkout = new SimpleStringProperty(checkout.format(formatter));
        this.affittoGiornaliero = new SimpleStringProperty(Double.toString(affittoGiornaliero)+" \u20ac");
    
        LocalDate ora = LocalDate.now( ZoneId.systemDefault() ); //(2)
        numeroNotti = DAYS.between(checkin, checkout); //(4)
        numeroNottiMeseCheckin = DAYS.between(checkin, LocalDate.of(checkout.getYear(), checkout.getMonth(), 1)); //notti trascorse nel mese precedente
        numeroNottiMeseCheckout = numeroNotti - numeroNottiMeseCheckin;
        valoreIncassoTotale = (affittoGiornaliero*numeroNotti);
        this.incassoTotale = new SimpleStringProperty(Double.toString(valoreIncassoTotale)+" \u20ac");
        
        if(ora.isAfter(checkout)){ //(3)
            this.stato = new SimpleStringProperty("Passato");
        }else{
            if(ora.isAfter(checkin) && checkout.isAfter(ora)){
                this.stato = new SimpleStringProperty("In Corso");
                valoreIncassoTotale = 0;
            }else{
                this.stato = new SimpleStringProperty("Prenotato");
                valoreIncassoTotale = 0;
            }
        }
        
        if(this.stato.get().equals("Passato")){
            valoreTasse = valoreIncassoTotale*percentualeTasse;
            valoreGuadagnoNetto = valoreIncassoTotale - valoreTasse;
            this.tasse = new SimpleStringProperty(Double.toString(valoreTasse)+" \u20ac");
            this.guadagnoNetto = new SimpleStringProperty(Double.toString(valoreGuadagnoNetto)+" \u20ac");
        }else{
            valoreTasse = 0;
            valoreGuadagnoNetto = 0;
            this.tasse = new SimpleStringProperty("-");
            this.guadagnoNetto = new SimpleStringProperty("-");
        }
        this.formattazione = formattazione;
    }
    
    public String getLocale(){return locale.get();} 
    public long getIdAffitto(){return idAffitto.get();} 
    public String getStato(){return stato.get();} 
    public String getCheckin(){return checkin.get();} 
    public String getCheckout(){return checkout.get();} 
    public String getAffittoGiornaliero(){return affittoGiornaliero.get();} 
    public String getIncassoTotale(){return incassoTotale.get();} 
    public String getTasse(){return tasse.get();} 
    public String getGuadagnoNetto(){return guadagnoNetto.get();}
    public double getValoreIncassoTotale() {return valoreIncassoTotale;}
    public double getValoreTasse() {return valoreTasse;}
    public double getValoreGuadagnoNetto() {return valoreGuadagnoNetto;}
    public String getMeseCheckout() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(formattazione); 
        return (dataCheckout.format(formatter));
    }
    public String getMeseCheckin() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(formattazione);
        return (dataCheckin.format(formatter));
    }
    public long getNumeroNotti() {return numeroNotti;}
    public long getNumeroNottiMeseCheckin() {return numeroNottiMeseCheckin;}
    public long getNumeroNottiMeseCheckout() {return numeroNottiMeseCheckout;}
    public LocalDate getDataCheckin() {return dataCheckin;}

}

/*
1. La libreria LocalDate mi permette di gestire le date
2. Perette di avere la LocalDate attuale relativa alla ZoneId di una certa area geografica
3. Calcolo i valori dello stato confrontando la LocalDate attuale a quella passata dal DBMS  
4. Permette di calcolare il numero gi giorni tra due volori LocalDate
*/
