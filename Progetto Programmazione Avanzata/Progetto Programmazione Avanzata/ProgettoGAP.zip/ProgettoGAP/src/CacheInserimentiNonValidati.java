/*CacheInserimentiNonValidati.java*/

import java.io.*;
import java.time.LocalDate;

public class CacheInserimentiNonValidati{
    
    public boolean salvaInCache(String locale, double affittoGiornaliero, LocalDate dal, LocalDate al){
        try( 
                FileOutputStream streamInUscita = new FileOutputStream("./cacheInserimenti.bin");
                ObjectOutputStream oggettoInUscita = new ObjectOutputStream(streamInUscita)
           ){
            oggettoInUscita.writeObject(new DatiFormInserimento(locale, affittoGiornaliero, dal, al));
            System.out.println("Cache salvata");
        }catch(IOException e){
                e.printStackTrace();
                return false;
        }
        return true;
    }
    
    public DatiFormInserimento caricaDaCache(){
        DatiFormInserimento datiForm = null;
        try( 
                FileInputStream streamInIngresso = new FileInputStream("./cacheInserimenti.bin");
                ObjectInputStream oggettoInIngresso = new ObjectInputStream(streamInIngresso)
           ){
            datiForm = (DatiFormInserimento) oggettoInIngresso.readObject();
            System.out.println("Prelevata cache");
        }catch(Exception e){
                e.printStackTrace();
        }
        if(datiForm == null){
            datiForm = new DatiFormInserimento("",0,LocalDate.now(),LocalDate.now());
        }
        return datiForm;
    }
}