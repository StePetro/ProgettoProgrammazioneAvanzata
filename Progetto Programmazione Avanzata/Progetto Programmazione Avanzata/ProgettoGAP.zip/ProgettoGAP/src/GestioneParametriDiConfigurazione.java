/*GestioneParametriDiConfigurazione.java*/

import com.thoughtworks.xstream.XStream;
import java.io.*;
import java.nio.file.*;
import javax.xml.*;
import javax.xml.parsers.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.*;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

public class GestioneParametriDiConfigurazione{

    public static Configurazione prelevaParametri() {
        Configurazione parametri = null;
        if(valida()){
            XStream xs = new XStream(); 
            String xml = xs.toXML(parametri); 
            try { 
                Files.write(Paths.get("cantina.txt"), xml.getBytes());
                xml = new String(Files.readAllBytes(Paths.get("fileDiConfigurazione.txt")));
            } catch (Exception e) {
                e.printStackTrace();
            }
            parametri = (Configurazione)xs.fromXML(xml); 
            System.out.println("Parametri di configurazione prelevati");
        }
        return parametri;
    }
    
    public static boolean valida() {
        try {  
                DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder(); 
                SchemaFactory schemaFactory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
                Document documento = db.parse(new File("fileDiConfigurazione.txt"));
                Schema schema = schemaFactory.newSchema(new StreamSource(new File("ValidazioneFileConfigurazione.xsd"))); 
                schema.newValidator().validate(new DOMSource(documento)); 
        } catch (ParserConfigurationException | SAXException | IOException e) {
            if (e instanceof SAXException) 
                System.out.println("Errore di validazione: " + e.getMessage());
            else
                System.out.println(e.getMessage());   
            return false;
        }
        return true;
    }
}